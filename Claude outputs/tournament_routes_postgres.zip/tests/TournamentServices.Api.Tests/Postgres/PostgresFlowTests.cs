using System.Net;
using System.Net.Http.Json;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Npgsql;
using TournamentServices.Api.Dtos;
using TournamentServices.Domain.Enums;
using TournamentServices.Repositories;

namespace TournamentServices.Api.Tests.Postgres;

// Solo corre si existe la variable de entorno TEST_POSTGRES con una
// connection string. Si no existe, el test aparece como "Skipped".
public sealed class PostgresFactAttribute : FactAttribute
{
    public const string VariableName = "TEST_POSTGRES";

    public PostgresFactAttribute()
    {
        if (string.IsNullOrWhiteSpace(Environment.GetEnvironmentVariable(VariableName)))
        {
            Skip = $"Define {VariableName} para correr las pruebas contra Postgres.";
        }
    }
}

// Prueba de punta a punta contra un Postgres real.
// Cada ejecucion crea su propia base (tournament_test_xxx) y la borra al final,
// asi no ensucia la base "tournament" que usa la API.
public class PostgresFlowTests : TournamentApiTests
{
    protected override void ConfigureDatabase(DbContextOptionsBuilder options, string databaseName)
    {
        var connection = new NpgsqlConnectionStringBuilder(
            Environment.GetEnvironmentVariable(PostgresFactAttribute.VariableName))
        {
            Database = $"tournament_test_{databaseName.Replace("-", "")[..12]}"
        };

        options.UseNpgsql(connection.ConnectionString);
    }

    [PostgresFact]
    public async Task FlujoCompleto_EquiposTorneoGruposYBorrado()
    {
        // 1. Crear dos equipos
        var pumas = await PostAsync<TeamDto>("/teams", new CreateTeamDto("Pumas"));
        var chivas = await PostAsync<TeamDto>("/teams", new CreateTeamDto("Chivas"));

        // 2. Nombre duplicado -> 400 (lo valida el delegate contra Postgres)
        var duplicated = await Client.PostAsJsonAsync("/teams", new CreateTeamDto("Pumas"), JsonOptions);
        Assert.Equal(HttpStatusCode.BadRequest, duplicated.StatusCode);

        // 3. Crear torneo
        var tournament = await PostAsync<TournamentDto>("/tournaments",
            new CreateTournamentDto("Copa Postgres", new FormatInputDto(2, 2, TournamentType.RoundRobin)));

        // 4. Crear grupo y repetir nombre sin importar mayusculas -> 422
        var groupsUrl = $"/tournaments/{tournament.Id}/groups";
        var group = await PostAsync<GroupDto>(groupsUrl, new CreateGroupDto("Grupo A"));
        var repeated = await Client.PostAsJsonAsync(groupsUrl, new CreateGroupDto("grupo a"), JsonOptions);
        Assert.Equal(HttpStatusCode.UnprocessableEntity, repeated.StatusCode);

        // 5. Asignar equipos (la lista TeamIds se guarda como JSON en Postgres)
        var assign = await Client.PatchAsJsonAsync($"{groupsUrl}/{group.Id}/teams",
            new AssignTeamsDto(new List<string> { pumas.Id, chivas.Id }), JsonOptions);
        Assert.Equal(HttpStatusCode.NoContent, assign.StatusCode);

        // 6. PATCH parcial del torneo
        var patch = await Client.PatchAsJsonAsync($"/tournaments/{tournament.Id}",
            new PatchTournamentDto("Copa Final", null), JsonOptions);
        Assert.Equal(HttpStatusCode.OK, patch.StatusCode);

        // 7. Leer el torneo completo: grupo con sus 2 equipos y formato intacto
        var loaded = await Client.GetFromJsonAsync<TournamentDto>($"/tournaments/{tournament.Id}", JsonOptions);
        Assert.Equal("Copa Final", loaded!.Name);
        Assert.Equal(new TournamentFormatDto(2, 2, TournamentType.RoundRobin), loaded.Format);
        var loadedGroup = Assert.Single(loaded.Groups);
        Assert.Equal(new[] { "Chivas", "Pumas" }, loadedGroup.Teams.Select(t => t.Name).OrderBy(n => n));

        // 8. Borrar el torneo borra sus grupos en cascada
        var delete = await Client.DeleteAsync($"/tournaments/{tournament.Id}");
        Assert.Equal(HttpStatusCode.NoContent, delete.StatusCode);
        Assert.False(await QueryAsync(db => db.Groups.AnyAsync(g => g.Id == group.Id)));

        // Los equipos no pertenecen al torneo, siguen existiendo
        Assert.True(await QueryAsync(db => db.Teams.AnyAsync(t => t.Id == pumas.Id)));
    }

    private async Task<T> PostAsync<T>(string url, object body)
    {
        var response = await Client.PostAsJsonAsync(url, body, JsonOptions);
        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        return (await response.Content.ReadFromJsonAsync<T>(JsonOptions))!;
    }

    public override void Dispose()
    {
        // Si el test se salto no se levanto ninguna base que borrar.
        if (!string.IsNullOrWhiteSpace(Environment.GetEnvironmentVariable(PostgresFactAttribute.VariableName)))
        {
            using var scope = Factory.Services.CreateScope();
            scope.ServiceProvider.GetRequiredService<TournamentDbContext>().Database.EnsureDeleted();
        }

        base.Dispose();
    }
}
